const alumnosReconocidos =
	[				
		{
          id: 1,
          nombre: "Ejercicios 1 SQL",
          fechaReconocimiento: "28/11/2023",
          fechaConsecucion: "04/12/2023",
		  alumnos: [ {first_name:"José",
		             last_name:"García"},
					 {first_name:"Antonio",
		             last_name:"Sánchez"},
					 {first_name:"María",
		             last_name:"López"}]
        },
        {
          id: 7,
          nombre: "Inglés Avanzado",
          fechaReconocimiento: "10/12/2023",
          fechaConsecucion: "16/12/2023",
		  alumnos: [ {first_name:"María",
		             last_name:"López"},
					 {first_name:"Ana",
		             last_name:"Gonzalez"},
					 {first_name:"Daniel",
		             last_name:"Rodriguez"},
					 {first_name:"Antonio",
		             last_name:"Sánchez"},
					 {first_name:"Andrea",
		             last_name:"Guardia"}]
        },
        {
          id: 2,
          nombre: "Diseño Gráfico Avanzado",
          fechaReconocimiento: "30/11/2023",
          fechaConsecucion: "06/12/2023",
		  alumnos: [ {first_name:"María",
		             last_name:"López"},
					 {first_name:"Ana",
		             last_name:"Gonzalez"},
					 {first_name:"José",
		             last_name:"García"},
					 {first_name:"Daniel",
		             last_name:"Rodriguez"}]
        }
	]
  