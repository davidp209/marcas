const reconocimientosAlumno = {
	
	first_name:"José",
	last_name:"García",	
	reconocimientos: [
					
		{
          id: 1,
          nombre: "Ejercicios 1 SQL",
          fechaReconocimiento: "28/11/2023",
          fechaConsecucion: "04/12/2023"
        },
        {
          id: 7,
          nombre: "Inglés Avanzado",
          fechaReconocimiento: "10/12/2023",
          fechaConsecucion: "16/12/2023"
        },
        {
          id: 2,
          nombre: "Diseño Gráfico Avanzado",
          fechaReconocimiento: "30/11/2023",
          fechaConsecucion: "06/12/2023"
        },
        {
          id: 4,
          nombre: "Gestión de Proyectos",
          fechaReconocimiento: "04/12/2023",
          fechaConsecucion: "10/12/2023"
        },
        {
          id: 5,
          nombre: "Marketing Digital",
          fechaReconocimiento: "06/12/2023",
          fechaConsecucion: "12/12/2023"
        },
        {
          id: 3,
          nombre: "Programación en Python",
          fechaReconocimiento: "02/12/2023",
          fechaConsecucion: "08/12/2023"
        },
        {
          id: 6,
          nombre: "Desarrollo Web",
          fechaReconocimiento: "08/12/2023",
          fechaConsecucion: "14/12/2023"
        },
        {
          id: 8,
          nombre: "Contabilidad Financiera",
          fechaReconocimiento: "12/12/2023",
          fechaConsecucion: "18/12/2023"
        },
        {
          id: 9,
          nombre: "Redes Informáticas",
          fechaReconocimiento: "14/12/2023",
          fechaConsecucion: "20/12/2023"
        },
        {
          id: 10,
          nombre: "Economía Internacional",
          fechaReconocimiento: "16/12/2023",
          fechaConsecucion: "22/12/2023"
        }]
}
  